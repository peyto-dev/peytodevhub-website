import React from 'react';
import Section from '../components/Section';
import { useLanguage } from '../contexts/LanguageContext';
import { Info, ArrowLeft, ShieldCheck } from 'lucide-react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

const CompanyDisclosure: React.FC = () => {
  const { t, language } = useLanguage();

  return (
    <div className="pt-24 bg-white min-h-screen">
      <Section>
        <div className="max-w-4xl mx-auto">
          <Link to="/" className="inline-flex items-center gap-2 text-[#64748B] hover:text-peyto-accent mb-10 transition-colors text-[11px] font-[800] uppercase tracking-widest group">
            <ArrowLeft size={14} className="group-hover:-translate-x-1 transition-transform" />
            {language === 'en' ? 'Back to Home' : '返回首頁'}
          </Link>
          
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="mb-12 border-b border-[#E2E8F0] pb-12"
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded bg-blue-50 border border-blue-100 flex items-center justify-center text-peyto-accent">
                 <Info size={20} />
              </div>
              <span className="text-[#64748B] font-mono text-[10px] tracking-widest uppercase font-bold">Compliance_Report_v1</span>
            </div>
            <h1 className="text-[44px] md:text-[52px] font-[800] text-[#0F172A] mb-4 uppercase tracking-tight">{t.disclosure.title}</h1>
          </motion.div>

          <div className="space-y-12">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="bg-white border border-[#CBD5E1] rounded-lg shadow-sm overflow-hidden"
            >
               <div className="p-8 md:p-12 border-b border-[#F1F5F9] bg-[#F8FAFC]">
                  <p className="text-[17px] text-[#334155] font-medium leading-relaxed italic">
                    {t.disclosure.content}
                  </p>
               </div>

               <div className="p-0">
                  <table className="w-full text-left">
                     <tbody>
                        {t.disclosure.details && t.disclosure.details.map((detail, idx) => (
                          <tr key={idx} className="border-b border-[#F1F5F9] last:border-0">
                             <td className="px-8 md:px-12 py-6 bg-slate-50 w-1/3 text-[11px] font-[800] uppercase tracking-wider text-[#64748B] border-r border-[#F1F5F9]">
                                {detail.label}
                             </td>
                             <td className="px-8 md:px-12 py-6 text-[15px] font-medium text-[#0F172A]">
                                {detail.value}
                             </td>
                          </tr>
                        ))}
                     </tbody>
                  </table>
               </div>

               <div className="p-8 md:p-12 bg-blue-50 border-t border-blue-100">
                  <div className="flex items-start gap-4">
                     <ShieldCheck size={20} className="text-peyto-accent shrink-0 mt-0.5" />
                     <div>
                        <h4 className="text-[12px] font-[800] text-[#0F172A] uppercase tracking-widest mb-2">Notice</h4>
                        <p className="text-[14px] text-[#475569] font-medium leading-relaxed">
                           {t.disclosure.notice}
                        </p>
                     </div>
                  </div>
               </div>

               <div className="px-8 md:px-12 py-6 bg-white flex justify-between items-center font-mono text-[9px] text-[#94A3B8] font-bold uppercase tracking-widest">
                  <span>Document ID: {new Date().getFullYear()}-PDHL-DISC-01</span>
                  <span>Ver: 1.0 Stable</span>
               </div>
            </motion.div>
          </div>
        </div>
      </Section>
    </div>
  );
};

export default CompanyDisclosure;