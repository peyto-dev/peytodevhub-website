import React, { useState } from 'react';
import { Mail, Loader2, Upload, File, X, Info, CheckCircle2, ShieldCheck } from 'lucide-react';
import Section from '../components/Section';
import Button from '../components/Button';
import { useLanguage } from '../contexts/LanguageContext';

const ContactPage: React.FC = () => {
  const { t } = useLanguage();
  const [formState, setFormState] = useState({
    name: '',
    email: '',
    phone: '',
    company: '',
    projectType: '',
    budget: '',
    message: '',
    ngo: '',
  });
  const [selectedFile, setSelectedFile] = useState<{ name: string; type: string; size: number; base64: string } | null>(null);
  const [touched, setTouched] = useState<Record<string, boolean>>({});
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const API_URL = "https://script.google.com/macros/s/AKfycbwKSED08-6cW7M_ljx-MZK4_zvTGRmPv2N8DNV-WHpzwYfeYe9v2S_EFeDfjxDxmng/exec";

  const validate = (values: typeof formState) => {
    const newErrors: Record<string, string> = {};
    if (!values.name.trim()) newErrors.name = t.contact.form.validation.required;
    if (!values.email.trim()) {
      newErrors.email = t.contact.form.validation.required;
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(values.email.trim())) {
      newErrors.email = t.contact.form.validation.email;
    }
    if (!values.phone.trim()) {
        newErrors.phone = t.contact.form.validation.required;
    }
    if (!values.company.trim()) newErrors.company = t.contact.form.validation.required;
    if (!values.projectType) newErrors.projectType = t.contact.form.validation.required;
    if (!values.budget) newErrors.budget = t.contact.form.validation.required;
    if (!values.message.trim()) {
        newErrors.message = t.contact.form.validation.required;
    }
    return newErrors;
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormState(prev => ({ ...prev, [name]: value }));
    if (touched[name]) {
       const newErrors = validate({ ...formState, [name]: value });
       setErrors(newErrors);
    }
  };

  const handleBlur = (e: React.FocusEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name } = e.target;
    setTouched(prev => ({ ...prev, [name]: true }));
    const newErrors = validate(formState);
    setErrors(newErrors);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        alert("File too large (Max 5MB)");
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
            setSelectedFile({ name: file.name, type: file.type, size: file.size, base64: reader.result });
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const removeFile = () => setSelectedFile(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const validationErrors = validate(formState);
    setErrors(validationErrors);
    setTouched(Object.keys(formState).reduce((acc, key) => ({...acc, [key]: true}), {}));
    
    if (Object.keys(validationErrors).length > 0) {
      const firstErrorField = Object.keys(validationErrors)[0];
      const element = document.getElementsByName(firstErrorField)[0];
      if (element) element.scrollIntoView({ behavior: 'smooth', block: 'center' });
      return;
    }
    
    setIsSubmitting(true);
    try {
      await fetch(API_URL, { 
        method: 'POST', 
        body: JSON.stringify({...formState, file: selectedFile}), 
        headers: { "Content-Type": "text/plain;charset=utf-8" } 
      });
      setIsSubmitted(true);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (error) {
      console.error(error);
      alert("Submission failed. Please try again or contact us directly via email.");
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isSubmitted) {
    return (
      <div className="pt-40 pb-32 peyto-container text-center bg-white min-h-screen">
        <div className="max-w-md mx-auto glass-morphism p-12 rounded-2xl shadow-xl relative overflow-hidden border-slate-100">
          <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-blue-600 to-indigo-600"></div>
          <div className="w-16 h-16 bg-blue-50 border border-blue-100 rounded-full flex items-center justify-center mx-auto mb-8 shadow-sm">
            <CheckCircle2 size={32} className="text-blue-600" />
          </div>
          <h2 className="text-2xl font-[800] text-slate-900 mb-4 uppercase tracking-tight">{t.contact.form.success_title}</h2>
          <p className="text-slate-500 mb-10 text-sm font-medium leading-relaxed">{t.contact.form.success_desc}</p>
          <div className="flex items-center gap-2 justify-center text-[10px] font-mono font-bold text-blue-600 uppercase tracking-widest mb-8">
             <ShieldCheck size={14} /> System_Received_Acknowledged
          </div>
          <Button onClick={() => setIsSubmitted(false)} variant="primary" className="w-full font-bold rounded-full border-none shadow-xl shadow-blue-600/10">
            {t.contact.form.send_another}
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-24 bg-white">
      <Section>
        <div className="grid lg:grid-cols-2 gap-20">
          {/* Information Column */}
          <div>
            <h1 className="text-[44px] md:text-[56px] font-[800] text-slate-900 mb-8 uppercase tracking-tight leading-tight">{t.contact.title}</h1>
            <p className="text-xl text-slate-500 mb-12 font-medium leading-relaxed">{t.contact.desc}</p>
            
            <div className="space-y-10 mb-16">
              <div className="flex items-start gap-5">
                <div className="w-12 h-12 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-center shrink-0">
                  <Mail className="text-blue-600" />
                </div>
                <div>
                  <h3 className="text-slate-400 font-[800] mb-2 uppercase text-[11px] tracking-widest">{t.contact.email}</h3>
                  <a href="mailto:info@peytodevhub.com" className="text-[18px] text-slate-900 font-bold hover:text-blue-600 transition-colors">info@peytodevhub.com</a>
                </div>
              </div>
            </div>

            <div className="p-10 bg-slate-50 border border-slate-100 rounded-2xl shadow-sm relative overflow-hidden">
              <div className="absolute top-0 right-0 p-4 opacity-10">
                 <ShieldCheck size={80} className="text-slate-200" />
              </div>
              <h4 className="font-[800] text-slate-900 mb-4 uppercase text-sm tracking-tight flex items-center gap-2">
                <Info size={18} className="text-blue-600" /> {t.contact.kickoff.title}
              </h4>
              <p className="text-sm text-slate-500 leading-relaxed font-medium italic">{t.contact.kickoff.desc}</p>
            </div>
          </div>

          {/* Form Column */}
          <div className="bg-white border border-slate-200 p-8 md:p-10 rounded-2xl shadow-xl relative">
            {isSubmitting && (
               <div className="absolute inset-0 z-20 bg-white/80 backdrop-blur-sm flex flex-col items-center justify-center rounded-2xl">
                  <Loader2 className="w-10 h-10 text-blue-600 animate-spin mb-4" />
                  <span className="text-slate-900 font-[800] text-[11px] uppercase tracking-widest">{t.contact.form.sending}</span>
               </div>
            )}
            
            <form onSubmit={handleSubmit} className="space-y-8" noValidate>
              <div className="grid md:grid-cols-2 gap-6 md:gap-8">
                <div className="space-y-2">
                  <label className="text-[11px] font-[800] text-slate-400 uppercase tracking-widest flex justify-between">
                    {t.contact.form.name}
                    {touched.name && errors.name && <span className="text-red-500 normal-case font-bold">{errors.name}</span>}
                  </label>
                  <input name="name" value={formState.name} onChange={handleChange} onBlur={handleBlur} className={`w-full bg-slate-50 border rounded-lg p-3.5 text-slate-900 focus:border-blue-600 outline-none font-bold transition-all ${touched.name && errors.name ? 'border-red-500 bg-red-50/50' : 'border-slate-200'}`} />
                </div>
                <div className="space-y-2">
                  <label className="text-[11px] font-[800] text-slate-400 uppercase tracking-widest flex justify-between">
                    {t.contact.form.email}
                    {touched.email && errors.email && <span className="text-red-500 normal-case font-bold">{errors.email}</span>}
                  </label>
                  <input type="email" name="email" value={formState.email} onChange={handleChange} onBlur={handleBlur} className={`w-full bg-slate-50 border rounded-lg p-3.5 text-slate-900 focus:border-blue-600 outline-none font-bold transition-all ${touched.email && errors.email ? 'border-red-500 bg-red-50/50' : 'border-slate-200'}`} />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6 md:gap-8">
                <div className="space-y-2">
                  <label className="text-[11px] font-[800] text-slate-400 uppercase tracking-widest flex justify-between">
                    {t.contact.form.phone}
                    {touched.phone && errors.phone && <span className="text-red-500 normal-case font-bold">{errors.phone}</span>}
                  </label>
                  <input name="phone" value={formState.phone} onChange={handleChange} onBlur={handleBlur} className={`w-full bg-slate-50 border rounded-lg p-3.5 text-slate-900 focus:border-blue-600 outline-none font-bold transition-all ${touched.phone && errors.phone ? 'border-red-500 bg-red-50/50' : 'border-slate-200'}`} />
                </div>
                <div className="space-y-2">
                  <label className="text-[11px] font-[800] text-slate-400 uppercase tracking-widest flex justify-between">
                    {t.contact.form.company}
                    {touched.company && errors.company && <span className="text-red-500 normal-case font-bold">{errors.company}</span>}
                  </label>
                  <input name="company" value={formState.company} onChange={handleChange} onBlur={handleBlur} className={`w-full bg-slate-50 border rounded-lg p-3.5 text-slate-900 focus:border-blue-600 outline-none font-bold transition-all ${touched.company && errors.company ? 'border-red-500 bg-red-50/50' : 'border-slate-200'}`} />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6 md:gap-8">
                <div className="space-y-2">
                  <label className="text-[11px] font-[800] text-slate-400 uppercase tracking-widest flex justify-between">
                    {t.contact.form.type}
                    {touched.projectType && errors.projectType && <span className="text-red-500 normal-case font-bold">{errors.projectType}</span>}
                  </label>
                  <select name="projectType" value={formState.projectType} onChange={handleChange} onBlur={handleBlur} className={`w-full bg-slate-50 border rounded-lg p-3.5 text-slate-900 focus:border-blue-600 outline-none font-bold transition-all appearance-none cursor-pointer ${touched.projectType && errors.projectType ? 'border-red-500 bg-red-50/50' : 'border-slate-200'}`}>
                    <option value="">{t.contact.form.type_opts.default}</option>
                    <option value="mvp">{t.contact.form.type_opts.website}</option>
                    <option value="app">{t.contact.form.type_opts.app}</option>
                    <option value="saas">{t.contact.form.type_opts.saas}</option>
                    <option value="impact">{t.contact.form.type_opts.impact}</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-[11px] font-[800] text-slate-400 uppercase tracking-widest flex justify-between">
                    {t.contact.form.budget}
                    {touched.budget && errors.budget && <span className="text-red-500 normal-case font-bold">{errors.budget}</span>}
                  </label>
                  <select name="budget" value={formState.budget} onChange={handleChange} onBlur={handleBlur} className={`w-full bg-slate-50 border rounded-lg p-3.5 text-slate-900 focus:border-blue-600 outline-none font-bold transition-all appearance-none cursor-pointer ${touched.budget && errors.budget ? 'border-red-500 bg-red-50/50' : 'border-slate-200'}`}>
                    <option value="">{t.contact.form.budget_opts.default}</option>
                    <option value="b1">{t.contact.form.budget_opts.b1}</option>
                    <option value="b2">{t.contact.form.budget_opts.b2}</option>
                    <option value="b3">{t.contact.form.budget_opts.b3}</option>
                    <option value="b4">{t.contact.form.budget_opts.b4}</option>
                  </select>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[11px] font-[800] text-slate-400 uppercase tracking-widest flex justify-between">
                  {t.contact.form.message}
                  {touched.message && errors.message && <span className="text-red-500 normal-case font-bold">{errors.message}</span>}
                </label>
                <textarea name="message" rows={4} value={formState.message} onChange={handleChange} onBlur={handleBlur} placeholder={t.contact.form.message_ph} className={`w-full bg-slate-50 border rounded-lg p-3.5 text-slate-900 focus:border-blue-600 outline-none font-bold transition-all resize-none ${touched.message && errors.message ? 'border-red-500 bg-red-50/50' : 'border-slate-200'}`} />
              </div>

              <div className="space-y-2">
                <label className="text-[11px] font-[800] text-slate-400 uppercase tracking-widest">
                  {t.contact.form.ngo}
                </label>
                <input name="ngo" value={formState.ngo} onChange={handleChange} className="w-full bg-slate-50 border border-slate-200 rounded-lg p-3.5 text-slate-900 focus:border-blue-600 outline-none font-bold transition-all" />
              </div>

              {/* File Attachment */}
              <div className="space-y-2">
                <label className="text-[11px] font-[800] text-slate-400 uppercase tracking-widest">
                  {t.contact.form.attachment_label}
                </label>
                {!selectedFile ? (
                  <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-slate-200 border-dashed rounded-xl cursor-pointer bg-slate-50 hover:bg-slate-100 hover:border-blue-300 transition-all group">
                    <div className="flex flex-col items-center justify-center pt-5 pb-6">
                      <Upload className="w-8 h-8 mb-2 text-slate-300 group-hover:text-blue-600 transition-colors" />
                      <p className="text-[12px] text-slate-500 font-bold uppercase tracking-wide">
                        {t.contact.form.attachment_placeholder}
                      </p>
                      <p className="text-[10px] text-slate-400 mt-1 uppercase tracking-widest">
                        {t.contact.form.attachment_help}
                      </p>
                    </div>
                    <input type="file" className="hidden" onChange={handleFileChange} accept=".pdf,.doc,.docx,.zip,.txt,.png,.jpg" />
                  </label>
                ) : (
                  <div className="flex items-center justify-between p-4 bg-blue-50 border border-blue-100 rounded-xl">
                    <div className="flex items-center gap-3">
                      <File className="text-blue-600" size={20} />
                      <div>
                        <p className="text-sm font-bold text-slate-900 max-w-[160px] md:max-w-[200px] truncate">{selectedFile.name}</p>
                        <p className="text-[10px] text-slate-400 uppercase font-bold tracking-widest">{(selectedFile.size / 1024 / 1024).toFixed(2)} MB</p>
                      </div>
                    </div>
                    <button type="button" onClick={removeFile} className="p-2 hover:bg-white rounded-full transition-colors text-slate-400 hover:text-red-600">
                      <X size={18} />
                    </button>
                  </div>
                )}
              </div>

              <Button type="submit" className="w-full h-14 font-bold text-base shadow-xl shadow-blue-600/10 border-none rounded-full">
                {t.contact.form.submit}
              </Button>
            </form>
          </div>
        </div>
      </Section>
    </div>
  );
};

export default ContactPage;