import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowRight, Package, Shield, Activity, Lock, Database, Code2, Workflow, Zap, Network, HelpCircle, ShieldCheck, Terminal } from 'lucide-react';
import { Link } from 'react-router-dom';
import Section from '../components/Section';
import Button from '../components/Button';
import { useLanguage } from '../contexts/LanguageContext';

const Home: React.FC = () => {
  const { t } = useLanguage();
  const [activeTab, setActiveTab] = useState(0);
  const [showTooltip, setShowTooltip] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveTab((prev) => (prev + 1) % t.home.trust_pillars.length);
      setShowTooltip(false);
    }, 5000);
    return () => clearInterval(timer);
  }, [t.home.trust_pillars.length]);

  const pillarIcons = [ShieldCheck, Lock, Terminal];

  return (
    <div className="bg-white">
      {/* Hero Section - LIGHT TECH THEME */}
      <section id="hero" className="relative pt-[120px] md:pt-[160px] pb-[60px] md:pb-[100px] hero-grid border-b border-slate-100 overflow-hidden">
        {/* Subtle Ambient Light (adjusted for light theme) */}
        <div className="absolute top-0 right-0 w-[500px] md:w-[1000px] h-[500px] md:h-[1000px] bg-blue-100/40 blur-[120px] rounded-full -translate-y-1/2 translate-x-1/2 pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-[400px] md:w-[800px] h-[400px] md:h-[800px] bg-slate-100/50 blur-[100px] rounded-full translate-y-1/2 -translate-x-1/2 pointer-events-none" />

        <div className="peyto-container relative z-10 grid md:grid-cols-10 gap-10 lg:gap-20 items-center">
          {/* Left: Headline & Description */}
          <motion.div 
            initial={{ opacity: 0, x: -30 }} 
            animate={{ opacity: 1, x: 0 }} 
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="md:col-span-6"
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 border border-blue-100 text-blue-600 text-[10px] font-bold tracking-[0.2em] uppercase mb-8 md:mb-10">
              <Zap size={12} className="fill-blue-600" /> {t.home.badge}
            </div>
            
            <h1 className="text-[38px] sm:text-[56px] lg:text-[76px] font-[800] leading-[1.1] md:leading-[0.95] mb-8 md:mb-10 text-slate-900 tracking-tighter max-w-[700px] break-words">
              {t.home.title_1} <br />
              <span className="text-blue-600">
                {t.home.title_2}
              </span> <br />
              {t.home.title_3}
            </h1>

            <p className="text-[16px] md:text-[18px] lg:text-[20px] text-slate-500 mb-10 md:mb-14 max-w-[550px] leading-relaxed font-medium">
              {t.home.intro}
            </p>

            <div className="flex flex-col sm:flex-row gap-4 md:gap-5">
              <Link to="/contact" className="w-full sm:w-auto">
                <Button variant="primary" className="w-full sm:min-w-[260px] h-[56px] md:h-[62px] text-base rounded-full border-none shadow-xl shadow-blue-600/10">
                  {t.home.cta_primary} <ArrowRight size={18} />
                </Button>
              </Link>
              <Link to="/portfolio" className="w-full sm:w-auto">
                <Button variant="secondary" className="w-full sm:min-w-[260px] h-[56px] md:h-[62px] text-base font-bold rounded-full bg-slate-50 border-slate-200 hover:bg-slate-100 text-slate-900">
                  {t.home.cta_secondary}
                </Button>
              </Link>
            </div>
          </motion.div>

          {/* Right: Technical Visualization */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }} 
            animate={{ opacity: 1, scale: 1 }} 
            transition={{ duration: 1, delay: 0.2 }} 
            className="md:col-span-4 relative flex flex-col items-center"
          >
            <div className="relative w-full aspect-square max-w-[450px] mb-8 animate-float hidden md:block">
               <svg viewBox="0 0 400 400" className="w-full h-full drop-shadow-[0_10px_30px_rgba(37,99,235,0.08)] overflow-visible">
                  <defs>
                    <radialGradient id="hubGlow" cx="50%" cy="50%" r="50%">
                      <stop offset="0%" stopColor="#3B82F6" stopOpacity="0.1" />
                      <stop offset="100%" stopColor="#3B82F6" stopOpacity="0" />
                    </radialGradient>
                    <linearGradient id="lineGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#2563EB" stopOpacity="0.4" />
                      <stop offset="100%" stopColor="#6366F1" stopOpacity="0.05" />
                    </linearGradient>
                  </defs>

                  <circle cx="200" cy="200" r="180" stroke="rgba(0,0,0,0.03)" strokeWidth="1" fill="none" />
                  <motion.circle 
                    cx="200" cy="200" r="180" stroke="url(#lineGrad)" strokeWidth="1.5" fill="none" 
                    strokeDasharray="10 350"
                    animate={{ rotate: 360 }} transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
                  />

                  <motion.circle 
                    cx="200" cy="200" r="150" stroke="rgba(0,0,0,0.05)" strokeWidth="1" fill="none" strokeDasharray="5 15"
                    animate={{ rotate: -360 }} transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
                  />

                  <g className="nodes">
                    <motion.g animate={{ y: [0, -8, 0] }} transition={{ duration: 4, repeat: Infinity }}>
                       <rect x="180" y="20" width="40" height="40" rx="10" fill="white" stroke="rgba(0,0,0,0.05)" strokeWidth="1" className="shadow-sm" />
                       <Shield x="190" y="30" size={20} className="text-blue-600" />
                       <path d="M200 60 L200 140" stroke="rgba(0,0,0,0.05)" strokeWidth="1" strokeDasharray="4 4" />
                    </motion.g>

                    <motion.g animate={{ x: [0, 8, 0] }} transition={{ duration: 5, repeat: Infinity, delay: 1 }}>
                       <rect x="340" y="180" width="40" height="40" rx="10" fill="white" stroke="rgba(0,0,0,0.05)" strokeWidth="1" className="shadow-sm" />
                       <Database x="350" y="190" size={20} className="text-blue-600" />
                       <path d="M340 200 L260 200" stroke="rgba(0,0,0,0.05)" strokeWidth="1" strokeDasharray="4 4" />
                    </motion.g>

                    <motion.g animate={{ y: [0, 8, 0] }} transition={{ duration: 6, repeat: Infinity, delay: 2 }}>
                       <rect x="180" y="340" width="40" height="40" rx="10" fill="white" stroke="rgba(0,0,0,0.05)" strokeWidth="1" className="shadow-sm" />
                       <Code2 x="190" y="350" size={20} className="text-blue-600" />
                       <path d="M200 340 L200 260" stroke="rgba(0,0,0,0.05)" strokeWidth="1" strokeDasharray="4 4" />
                    </motion.g>

                    <motion.g animate={{ x: [0, -8, 0] }} transition={{ duration: 4.5, repeat: Infinity, delay: 0.5 }}>
                       <rect x="20" y="180" width="40" height="40" rx="10" fill="white" stroke="rgba(0,0,0,0.05)" strokeWidth="1" className="shadow-sm" />
                       <Network x="30" y="190" size={20} className="text-blue-600" />
                       <path d="M60 200 L140 200" stroke="rgba(0,0,0,0.05)" strokeWidth="1" strokeDasharray="4 4" />
                    </motion.g>
                  </g>
                  
                  <circle cx="200" cy="200" r="70" fill="url(#hubGlow)" />
                  <motion.g animate={{ rotate: 360 }} transition={{ duration: 60, repeat: Infinity, ease: "linear" }}>
                    <rect x="165" y="165" width="70" height="70" rx="14" fill="white" stroke="#2563EB" strokeWidth="2" className="shadow-lg" />
                  </motion.g>
                  <Workflow x="185" y="185" size={30} className="text-blue-600" />
               </svg>
            </div>

            {/* Trust Console */}
            <div className="relative w-full glass-morphism rounded-2xl p-6 md:p-8 z-20 shadow-2xl border-white">
              <div className="flex items-center justify-between mb-8 pb-4 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 bg-blue-600 rounded-full animate-pulse shadow-[0_0_8px_rgba(37,99,235,0.3)]" />
                  <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-widest">Protocol_Verify_Stream</span>
                </div>
                <div className="flex gap-1">
                  {t.home.trust_pillars.map((_, idx) => (
                    <div 
                      key={idx} 
                      className={`h-1 w-6 rounded-full transition-all duration-500 ${idx === activeTab ? 'bg-blue-600 w-10' : 'bg-slate-200'}`}
                    />
                  ))}
                </div>
              </div>

              <div className="min-h-[140px] md:min-h-[160px]">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={activeTab}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ duration: 0.4 }}
                  >
                    <div className="flex items-center gap-4 mb-5">
                      <div className="w-12 h-12 rounded-xl bg-blue-50 border border-blue-100 flex items-center justify-center text-blue-600">
                        {React.createElement(pillarIcons[activeTab], { size: 24 })}
                      </div>
                      <div className="relative">
                        <div className="text-[10px] font-mono font-bold text-blue-500 uppercase tracking-widest mb-0.5">
                          {t.home.trust_pillars[activeTab].status}
                        </div>
                        <h3 
                          className="text-[17px] font-bold text-slate-900 uppercase tracking-tight flex items-center gap-2 cursor-help group"
                          onMouseEnter={() => setShowTooltip(true)}
                          onMouseLeave={() => setShowTooltip(false)}
                        >
                          {t.home.trust_pillars[activeTab].title}
                          <HelpCircle size={14} className="text-slate-300 group-hover:text-blue-600 transition-colors" />

                          {/* Tooltip */}
                          <AnimatePresence>
                            {showTooltip && (activeTab === 0) && (
                              <motion.div
                                initial={{ opacity: 0, y: 10, scale: 0.95 }}
                                animate={{ opacity: 1, y: 0, scale: 1 }}
                                exit={{ opacity: 0, y: 10, scale: 0.95 }}
                                className="absolute bottom-full left-0 mb-4 w-[280px] p-5 bg-white border border-slate-200 text-slate-500 text-[12px] leading-relaxed font-medium rounded-xl shadow-2xl z-50 pointer-events-none"
                              >
                                <div className="flex items-center gap-2 mb-3 text-blue-600 font-bold uppercase text-[9px] tracking-widest">
                                  <ShieldCheck size={12} /> Milestone_Verification_Logic
                                </div>
                                {t.home.trust_pillars[0].tooltip}
                                <div className="absolute top-full left-6 w-3 h-3 bg-white border-r border-b border-slate-200 rotate-45 -translate-y-1.5" />
                              </motion.div>
                            )}
                          </AnimatePresence>
                        </h3>
                      </div>
                    </div>
                    <p className="text-[14px] text-slate-500 leading-relaxed font-medium">
                      {t.home.trust_pillars[activeTab].desc}
                    </p>
                  </motion.div>
                </AnimatePresence>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Internal Mindset Quote */}
      <div className="bg-slate-50 py-16 border-y border-slate-100">
        <div className="peyto-container text-center">
            <p className="text-slate-500 text-[16px] font-medium max-w-2xl mx-auto leading-relaxed italic">
                "{t.home.internal_mindset}"
            </p>
        </div>
      </div>

      {/* Deliverables Section */}
      <Section id="deliverables" className="bg-white">
        <div className="text-center mb-16 max-w-2xl mx-auto">
          <h2 className="text-[10px] font-bold mb-4 text-blue-600 uppercase tracking-[0.3em]">{t.home.deliverables.title}</h2>
          <p className="text-[32px] md:text-[40px] font-bold text-slate-900 tracking-tight leading-tight">{t.home.deliverables.subtitle}</p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6">
          {t.home.deliverables.items.map((item, idx) => (
            <div key={idx} className="peyto-card p-8 group hover:border-blue-300">
              <div className="w-10 h-10 rounded-lg bg-slate-50 flex items-center justify-center mb-6 text-slate-400 group-hover:text-blue-600 transition-colors">
                <Package size={20} />
              </div>
              <h4 className="text-slate-900 font-bold mb-3 text-[12px] uppercase tracking-widest">{item.title}</h4>
              <p className="text-slate-500 text-[12px] leading-relaxed font-medium">{item.desc}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* Milestone Trust Table */}
      <Section id="milestones" className="bg-slate-50 border-y border-slate-100">
        <div className="peyto-container">
          <div className="text-center mb-16">
            <h2 className="text-[10px] font-bold mb-4 text-blue-600 uppercase tracking-[0.3em]">{t.home.milestone_table.title}</h2>
            <p className="text-[32px] font-bold text-slate-900 tracking-tight">{t.home.milestone_table.subtitle}</p>
          </div>
          <div className="overflow-x-auto bg-white border border-slate-200 rounded-2xl shadow-xl">
            <table className="w-full text-left border-collapse min-w-[600px]">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-100">
                  {t.home.milestone_table.headers.map((h, i) => (
                    <th key={i} className="px-8 py-5 text-[10px] font-mono text-slate-400 uppercase tracking-widest font-bold">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="text-[14px]">
                {t.home.milestone_table.rows.map((row, i) => (
                  <tr key={i} className="border-b border-slate-50 last:border-0 hover:bg-slate-50 transition-colors">
                    <td className="px-8 py-5 text-slate-900 font-bold">{row[0]}</td>
                    <td className="px-8 py-5 text-slate-500 font-medium">{row[1]}</td>
                    <td className="px-8 py-5">
                      <div className="flex items-center gap-2 text-blue-600 font-mono text-[11px] font-bold uppercase tracking-widest">
                        <Shield size={14} /> {row[2]}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </Section>

      {/* Results Stats */}
      <Section id="results" className="bg-white pb-24">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
          {t.home.stats.items.map((stat, index) => (
            <div key={index} className="peyto-card p-8 md:p-12 text-center group">
                 <div className="text-[32px] md:text-[44px] font-black text-slate-900 mb-2 tracking-tighter group-hover:text-blue-600 transition-colors">
                   {stat.value}
                 </div>
                 <div className="text-slate-400 font-mono text-[10px] uppercase tracking-[0.3em] font-bold">
                   {stat.label}
                 </div>
            </div>
          ))}
        </div>
      </Section>
    </div>
  );
};

export default Home;