import React from 'react';
import { Heart, Target, ShieldAlert, Info, ShieldCheck, HelpCircle } from 'lucide-react';
import { motion } from 'framer-motion';
import Section from '../components/Section';
import { useLanguage } from '../contexts/LanguageContext';

const ImpactPage: React.FC = () => {
  const { t } = useLanguage();

  return (
    <div className="pt-24 bg-white min-h-screen">
      <Section>
        <div className="text-center mb-16 max-w-4xl mx-auto">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded bg-blue-50 border border-blue-100 text-peyto-accent text-[11px] font-[800] uppercase tracking-widest mb-8">
            <Heart size={14} className="fill-peyto-accent" /> {t.impact.pledge_badge}
          </div>
          <h1 className="text-[44px] md:text-[52px] font-[800] text-[#0F172A] mb-8 whitespace-pre-line tracking-tight uppercase leading-tight">
            {t.impact.title}
          </h1>
          <p className="text-xl text-[#475569] leading-relaxed mb-10 font-medium">
            {t.impact.desc}
          </p>
          
          <div className="p-8 bg-[#FFF7ED] border border-[#FFEDD5] rounded-lg flex items-start gap-5 text-left mb-16 max-w-2xl mx-auto shadow-sm">
             <ShieldAlert className="text-orange-600 shrink-0 mt-0.5" size={20} />
             <p className="text-sm text-[#9A3412] leading-relaxed font-bold italic">
                {t.impact.disclaimer}
             </p>
          </div>

          <div className="space-y-12 text-left">
             <motion.div 
               initial={{ opacity: 0, y: 10 }}
               whileInView={{ opacity: 1, y: 0 }}
               viewport={{ once: true }}
               className="bg-white border border-[#CBD5E1] p-12 rounded-lg shadow-sm"
             >
                <div className="space-y-8 text-[17px] text-[#334155] leading-relaxed font-medium">
                  <p>{t.impact.body_1}</p>
                  <p>{t.impact.body_2}</p>
                </div>
             </motion.div>

             <div className="grid md:grid-cols-2 gap-10">
                <motion.div 
                  initial={{ opacity: 0, x: -10 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  className="bg-white border border-[#E2E8F0] p-10 rounded-lg shadow-sm"
                >
                    <div className="w-12 h-12 rounded bg-blue-50 border border-blue-100 flex items-center justify-center mb-8 text-peyto-accent">
                        <Target size={22} />
                    </div>
                    <h2 className="text-[20px] font-[800] text-[#0F172A] mb-4 uppercase tracking-tight">{t.impact.meaning_title}</h2>
                    <p className="text-[#475569] leading-relaxed text-[15px] font-medium">
                        {t.impact.meaning_body}
                    </p>
                </motion.div>

                <motion.div 
                  initial={{ opacity: 0, x: 10 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  className="bg-[#F8FAFC] border border-[#E2E8F0] p-10 rounded-lg shadow-sm"
                >
                    <div className="w-12 h-12 rounded bg-white border border-[#CBD5E1] flex items-center justify-center mb-8 text-slate-400">
                        <HelpCircle size={22} />
                    </div>
                    <h2 className="text-[20px] font-[800] text-slate-500 mb-4 uppercase tracking-tight">{t.impact.not_title}</h2>
                    <p className="text-[#64748B] leading-relaxed text-[15px] font-medium">
                        {t.impact.not_body}
                    </p>
                </motion.div>
             </div>

             <motion.div 
               initial={{ opacity: 0, y: 10 }}
               whileInView={{ opacity: 1, y: 0 }}
               viewport={{ once: true }}
               className="bg-white border border-[#CBD5E1] p-12 rounded-lg shadow-sm"
             >
                <h2 className="text-[24px] font-[800] text-[#0F172A] mb-8 uppercase tracking-tight">{t.impact.accountability_title}</h2>
                <p className="text-[#334155] text-[17px] font-medium leading-relaxed mb-12">
                    {t.impact.accountability_body}
                </p>
                
                <div className="border-t border-[#E2E8F0] pt-12">
                  <div className="flex items-center gap-3 text-peyto-accent font-mono text-[11px] uppercase tracking-widest font-bold mb-6">
                     <ShieldCheck size={20} />
                     {t.impact.closing_title}
                  </div>
                  <p className="text-[16px] text-[#475569] leading-relaxed font-medium italic">
                     {t.impact.closing_body}
                  </p>
                </div>
             </motion.div>
          </div>
        </div>

        <div className="mt-24 p-12 border border-[#CBD5E1] rounded-lg bg-[#F8FAFC] text-center max-w-3xl mx-auto shadow-sm">
            <Info className="mx-auto text-slate-400 mb-8" size={28} />
            <p className="text-[10px] text-[#64748B] uppercase tracking-[0.25em] font-mono mb-8 font-[800]">
                Operational Statement
            </p>
            <p className="text-[16px] text-[#334155] leading-relaxed italic max-w-2xl mx-auto font-medium">
                "Our primary responsibility is — and will always be — to our clients: delivering clear scopes, verified milestones, and production-ready code with transparent ownership. Social responsibility is simply part of how we choose to operate as a studio."
            </p>
        </div>
      </Section>
    </div>
  );
};

export default ImpactPage;