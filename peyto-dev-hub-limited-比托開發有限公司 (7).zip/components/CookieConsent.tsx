import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Button from './Button';
import { useLanguage } from '../contexts/LanguageContext';
import { Cookie } from 'lucide-react';
import { Link } from 'react-router-dom';

const CookieConsent: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);
  const { t } = useLanguage();

  useEffect(() => {
    const consent = localStorage.getItem('peyto_cookie_consent');
    if (!consent) {
        const timer = setTimeout(() => setIsVisible(true), 1500);
        return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('peyto_cookie_consent', 'true');
    setIsVisible(false);
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 50, opacity: 0 }}
          className="fixed bottom-0 left-0 right-0 z-50 p-6 flex justify-center pointer-events-none"
        >
          <div className="pointer-events-auto max-w-4xl w-full bg-white border border-slate-200 rounded-xl p-6 md:flex items-center justify-between gap-8 shadow-2xl">
            <div className="flex items-start gap-4 mb-4 md:mb-0">
               <div className="w-10 h-10 rounded-lg bg-blue-50 border border-blue-100 flex items-center justify-center shrink-0">
                  <Cookie className="text-blue-600" size={20} />
               </div>
               <div>
                  <h4 className="text-slate-900 font-bold mb-0.5 text-sm uppercase tracking-tight">{t.cookie_consent.title}</h4>
                  <p className="text-[12px] text-slate-500 leading-relaxed">
                    {t.cookie_consent.desc}{' '}
                    <Link to="/privacy" className="text-blue-600 hover:underline underline-offset-4 decoration-blue-600/30 font-bold">
                      {t.footer.privacy}
                    </Link>
                  </p>
               </div>
            </div>
            <div className="flex items-center gap-3 shrink-0">
                <Button onClick={handleAccept} variant="primary" className="!py-2 !px-8 !text-xs !rounded-md uppercase tracking-widest font-bold">
                  {t.cookie_consent.accept}
                </Button>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default CookieConsent;