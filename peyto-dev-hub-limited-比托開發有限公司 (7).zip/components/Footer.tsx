import React from 'react';
import { Mail, Globe, Info, ShieldCheck } from 'lucide-react';
import { Link } from 'react-router-dom';
import Logo from './Logo';
import { useLanguage } from '../contexts/LanguageContext';

const Footer: React.FC = () => {
  const { t } = useLanguage();

  return (
    <footer className="border-t border-slate-100 bg-white pt-20 pb-12">
      <div className="peyto-container">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-16 mb-20">
          <div className="col-span-1 lg:col-span-2">
            <div className="mb-8"><Logo className="h-10" textClassName="text-lg" /></div>
            <p className="text-slate-500 text-[15px] font-medium max-w-sm mb-10 leading-relaxed">{t.footer.desc}</p>
            
            <div className="flex flex-col gap-4">
              <div className="flex items-center gap-3 text-blue-600 bg-blue-50 border border-blue-100 px-5 py-2.5 rounded w-fit">
                <ShieldCheck size={18} />
                <span className="text-[11px] font-[800] uppercase tracking-widest">{t.footer.donation_note}</span>
              </div>
              
              <div className="space-y-3 font-mono text-[10px] text-slate-400 font-bold uppercase tracking-widest">
                 <div className="flex items-center gap-2">
                   <Globe size={14} className="text-slate-300" />
                   {t.footer.jurisdiction}
                 </div>
                 <div className="flex items-center gap-2">
                   <Info size={14} className="text-slate-300" />
                   {t.footer.reg_no}
                 </div>
              </div>
            </div>
          </div>

          <div>
            <h4 className="text-slate-400 font-[800] mb-8 uppercase text-[11px] tracking-widest">{t.footer.explore}</h4>
            <ul className="space-y-4 text-slate-900 text-sm font-bold">
              <li><Link to="/" className="hover:text-blue-600 transition-colors">{t.nav.home}</Link></li>
              <li><Link to="/services" className="hover:text-blue-600 transition-colors">{t.nav.services}</Link></li>
              <li><Link to="/portfolio" className="hover:text-blue-600 transition-colors">{t.nav.portfolio}</Link></li>
              <li><Link to="/impact" className="hover:text-blue-600 transition-colors">{t.nav.impact}</Link></li>
              <li><Link to="/about" className="hover:text-blue-600 transition-colors">{t.nav.about}</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="text-slate-400 font-[800] mb-8 uppercase text-[11px] tracking-widest">{t.footer.connect}</h4>
            <ul className="space-y-4 text-slate-900 text-sm font-bold">
              <li><Link to="/contact" className="hover:text-blue-600 transition-colors">{t.nav.contact}</Link></li>
              <li><a href="mailto:info@peytodevhub.com" className="hover:text-blue-600 transition-colors flex items-center gap-2 uppercase tracking-wide"><Mail size={16} /> info@peytodevhub.com</a></li>
              <li className="pt-8 border-t border-slate-100">
                 <span className="text-[10px] text-slate-400 uppercase tracking-[0.2em] font-[800]">{t.footer.operational}</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Legal Disclaimer Box */}
        <div className="bg-slate-50 border border-slate-100 p-8 rounded-lg mb-12">
            <div className="text-[11px] text-slate-500 leading-relaxed text-center italic space-y-2 font-medium max-w-2xl mx-auto">
                {t.footer.legal_disclaimer.map((line, i) => (
                  <p key={i}>{line}</p>
                ))}
            </div>
        </div>

        {/* Bottom Legal */}
        <div className="border-t border-slate-100 pt-10 flex flex-col md:flex-row justify-between items-center gap-6 text-[10px] text-slate-400 uppercase font-mono tracking-widest font-bold">
          <p>© {new Date().getFullYear()} {t.footer.company_name}. {t.footer.rights}</p>
          <div className="flex gap-8">
            <Link to="/disclosure" className="hover:text-slate-900 transition-colors">{t.footer.disclosure}</Link>
            <Link to="/privacy" className="hover:text-slate-900 transition-colors">{t.footer.privacy}</Link>
            <Link to="/terms" className="hover:text-slate-900 transition-colors">{t.footer.terms}</Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;