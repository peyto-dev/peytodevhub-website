import React from 'react';

interface LogoProps {
  className?: string; // height class for the icon
  textClassName?: string; // text sizing
}

const Logo: React.FC<LogoProps> = ({ className = "h-10", textClassName = "text-xl" }) => {
  return (
    <div className="flex items-center gap-3 select-none" aria-label="Peyto Dev Hub Logo">
      <div className={`${className} aspect-square relative`}>
        <svg
          viewBox="0 0 100 100"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="h-full w-auto"
          style={{ overflow: 'visible' }}
        >
           {/* Left Shape (P) - Blue */}
           <path 
             d="M48 0 L12 20 L12 70 L32 70 L32 50 L48 50 Z M32 30 L40 30 L40 40 L32 40 Z" 
             fill="#2563EB"
             fillRule="evenodd"
           />
           
           {/* Right Shape (Mirrored) - Dark Slate */}
           <path 
             d="M52 0 L88 20 L88 70 L68 70 L68 50 L52 50 Z M68 30 L60 30 L60 40 L68 40 Z" 
             fill="#0F172A"
             fillRule="evenodd"
           />

           {/* Accent Lines - Blue */}
           <g stroke="#2563EB" strokeWidth="6" strokeLinecap="round">
             <path d="M25 82 H75" />
             <path d="M35 94 H65" />
           </g>
        </svg>
      </div>
      
      <div className={`flex flex-col justify-center ${textClassName}`}>
        <span className="font-[800] tracking-tight text-slate-900 leading-none block">
          <span className="text-blue-600">Peyto</span> Dev Hub
        </span>
        <span className="font-[700] tracking-tight text-slate-500 leading-tight block mt-0.5 text-[0.85em] opacity-80 uppercase tracking-widest font-mono">
          比托開發有限公司
        </span>
      </div>
    </div>
  );
};

export default Logo;