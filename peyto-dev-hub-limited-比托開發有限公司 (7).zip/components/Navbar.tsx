import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Globe, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import Button from './Button';
import Logo from './Logo';
import { useLanguage } from '../contexts/LanguageContext';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();
  const { language, setLanguage, t } = useLanguage();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsOpen(false);
  }, [location]);

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  const navLinks = [
    { name: t.nav.home, path: '/' },
    { name: t.nav.services, path: '/services' },
    { name: t.nav.portfolio, path: '/portfolio' },
    { name: t.nav.impact, path: '/impact' },
    { name: t.nav.about, path: '/about' },
  ];

  return (
    <nav 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled || isOpen ? 'bg-white/90 border-b border-slate-100 py-3 backdrop-blur-xl shadow-sm' : 'bg-transparent py-5'
      }`}
    >
      <div className="peyto-container flex justify-between items-center relative z-50">
        <Link to="/" className="hover:opacity-90 transition-opacity" onClick={() => setIsOpen(false)}>
          <Logo className="h-9 md:h-10" textClassName="text-base md:text-lg" />
        </Link>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => {
            const isActive = location.pathname === link.path;
            return (
              <Link 
                key={link.path} 
                to={link.path}
                className={`text-[11px] uppercase tracking-[0.15em] transition-all duration-200 ${
                  isActive ? 'text-blue-600 font-bold' : 'text-slate-500 font-semibold hover:text-slate-900'
                }`}
              >
                {link.name}
              </Link>
            );
          })}
          
          <div className="h-4 w-[1px] bg-slate-200"></div>

          <div className="flex flex-col items-end gap-0.5">
            <button 
              onClick={() => setLanguage(language === 'en' ? 'zh' : 'en')}
              className="flex items-center gap-1 text-[10px] font-bold text-slate-400 hover:text-slate-900 transition-colors uppercase tracking-widest"
            >
              <Globe size={13} />
              <span>{language === 'en' ? 'EN' : '繁中'}</span>
            </button>
            <div className="flex items-center gap-1 text-[9px] font-bold text-green-600 uppercase tracking-widest">
              <CheckCircle2 size={10} /> {t.nav.micro_trust}
            </div>
          </div>

          <Link to="/contact">
            <Button variant="primary" className="!py-2 !px-5 !text-[11px] !rounded-full uppercase tracking-widest font-bold border-none shadow-md shadow-blue-600/10">
              {t.nav.contact}
            </Button>
          </Link>
        </div>

        <button className="md:hidden text-slate-900 p-2" onClick={() => setIsOpen(!isOpen)} aria-label="Toggle Menu">
          {isOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, x: '100%' }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: '100%' }}
            className="md:hidden fixed inset-0 z-40 bg-white pt-20 px-8 flex flex-col"
          >
            <div className="flex flex-col gap-5 mt-4">
              {navLinks.map((link) => (
                <Link key={link.path} to={link.path} className="text-xl font-bold py-3 text-slate-900 uppercase tracking-widest border-b border-slate-100" onClick={() => setIsOpen(false)}>
                  {link.name}
                </Link>
              ))}
              <div className="mt-8 flex flex-col gap-5">
                 <Link to="/contact" onClick={() => setIsOpen(false)}>
                   <Button variant="primary" className="w-full justify-center py-4 !rounded-lg uppercase tracking-widest font-bold border-none">
                     {t.nav.contact}
                   </Button>
                 </Link>
                 <div className="flex items-center justify-between">
                   <button onClick={() => setLanguage(language === 'en' ? 'zh' : 'en')} className="text-slate-500 font-bold uppercase tracking-widest text-xs flex items-center gap-2">
                     <Globe size={16} /> {language === 'en' ? 'SWITCH TO CHINESE' : '切換至繁中'}
                   </button>
                   <span className="text-[9px] font-bold text-green-600 uppercase tracking-widest">{t.nav.micro_trust}</span>
                 </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

export default Navbar;