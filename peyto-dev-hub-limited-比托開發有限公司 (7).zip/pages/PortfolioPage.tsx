import React from 'react';
import { Tag, Clock, Layers, Target, Settings, GitBranch, Briefcase, Terminal, CheckCircle2, ShieldCheck, Activity, Info, Lock } from 'lucide-react';
import Section from '../components/Section';
import { useLanguage } from '../contexts/LanguageContext';
import { motion } from 'framer-motion';

const PortfolioPage: React.FC = () => {
  const { t } = useLanguage();

  const projectImages = [
    "https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=2070&auto=format&fit=crop", // Enterprise Resource Portal (Data Dashboard)
    "https://images.unsplash.com/photo-1601972599720-36938d4ecd31?q=80&w=1974&auto=format&fit=crop", // Service Matching Engine (Realistic App UI Layout)
    "https://images.unsplash.com/photo-1666214280557-f1b5022eb634?q=80&w=2070&auto=format&fit=crop"  // Medical Learning SaaS (Medicine Dashboard)
  ];

  return (
    <div className="pt-24 bg-white">
      <Section>
        <div className="mb-16 border-b border-slate-100 pb-12">
          <h1 className="text-[44px] md:text-[56px] font-[800] text-slate-900 mb-6 uppercase tracking-tight leading-tight">
            {t.portfolio.title}
          </h1>
          <p className="text-xl text-slate-500 max-w-3xl leading-relaxed font-medium">
            {t.portfolio.desc}
          </p>
        </div>

        <div className="grid gap-16">
          {t.portfolio.projects.map((project, index) => (
            <motion.div 
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="group relative bg-white border border-slate-200 rounded-2xl overflow-hidden flex flex-col lg:flex-row min-h-[600px] shadow-sm hover:shadow-xl hover:border-blue-200 transition-all duration-500"
            >
              
              {/* Left Column: Technical Metadata */}
              <div className="p-10 lg:p-14 lg:w-[55%] flex flex-col justify-center border-b lg:border-b-0 lg:border-r border-slate-100 relative z-10">
                <div className="flex items-center gap-4 mb-8">
                  <div className="px-3 py-1 bg-blue-50 border border-blue-100 text-blue-600 text-[10px] font-bold tracking-widest uppercase rounded">
                    {project.category}
                  </div>
                  <div className="flex items-center gap-2 px-3 py-1 bg-slate-50 border border-slate-100 text-slate-500 text-[10px] font-bold tracking-widest uppercase rounded">
                    <Info size={12} /> {t.portfolio.sample_badge}
                  </div>
                </div>
                
                <h3 className="text-[36px] font-[800] text-slate-900 mb-12 tracking-tighter leading-tight group-hover:text-blue-600 transition-colors duration-300">
                  {project.title}
                </h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-y-10 gap-x-12">
                   <div className="flex items-start gap-4">
                      <div className="w-10 h-10 rounded-lg bg-slate-50 border border-slate-100 flex items-center justify-center shrink-0">
                        <Briefcase size={16} className="text-slate-400"/>
                      </div>
                      <div>
                         <div className="text-[10px] text-slate-500 font-bold uppercase tracking-[0.2em] mb-1.5">{t.portfolio.columns.client}</div>
                         <div className="text-[15px] text-slate-900 font-semibold">{(project as any).client}</div>
                      </div>
                   </div>

                   <div className="flex items-start gap-4">
                      <div className="w-10 h-10 rounded-lg bg-slate-50 border border-slate-100 flex items-center justify-center shrink-0">
                        <Target size={16} className="text-slate-400"/>
                      </div>
                      <div>
                         <div className="text-[10px] text-slate-500 font-bold uppercase tracking-[0.2em] mb-1.5">{t.portfolio.columns.problem}</div>
                         <div className="text-[15px] text-slate-600 font-medium leading-relaxed">{project.problem}</div>
                      </div>
                   </div>

                   <div className="flex items-start gap-4 md:col-span-2 bg-slate-50 p-6 rounded-xl border border-slate-100">
                      <div className="w-10 h-10 rounded bg-blue-50 border border-blue-100 flex items-center justify-center shrink-0">
                        <GitBranch size={16} className="text-blue-600"/>
                      </div>
                      <div className="ml-2">
                         <div className="text-[10px] text-slate-500 font-bold uppercase tracking-[0.2em] mb-1.5">{t.portfolio.columns.outcome}</div>
                         <div className="text-[16px] text-blue-600 font-bold uppercase tracking-wide">{project.outcome}</div>
                      </div>
                   </div>

                   <div className="flex items-start gap-4">
                      <div className="w-10 h-10 rounded-lg bg-slate-50 border border-slate-100 flex items-center justify-center shrink-0">
                        <Settings size={16} className="text-slate-400"/>
                      </div>
                      <div>
                         <div className="text-[10px] text-slate-500 font-bold uppercase tracking-[0.2em] mb-1.5">{t.portfolio.columns.stack}</div>
                         <div className="text-[14px] text-slate-600 font-mono font-bold">{project.stack}</div>
                      </div>
                   </div>
                   <div className="flex items-start gap-4">
                      <div className="w-10 h-10 rounded-lg bg-slate-50 border border-slate-100 flex items-center justify-center shrink-0">
                        <Clock size={16} className="text-slate-400"/>
                      </div>
                      <div>
                         <div className="text-[10px] text-slate-500 font-bold uppercase tracking-[0.2em] mb-1.5">{t.portfolio.columns.timeline}</div>
                         <div className="text-[15px] text-slate-600 font-semibold">{project.timeline}</div>
                      </div>
                   </div>
                </div>
              </div>
              
              {/* Right Column: UI Display */}
              <div className="lg:w-[45%] relative overflow-hidden flex flex-col bg-slate-100">
                 <div className="absolute inset-0 z-0">
                    <img 
                      src={projectImages[index % projectImages.length]} 
                      alt="Project UI Showcase" 
                      className="w-full h-full object-cover group-hover:scale-110 transition-all duration-1000 grayscale-[0.2] group-hover:grayscale-0 opacity-80" 
                    />
                    <div className="absolute inset-0 bg-blue-600/5 mix-blend-overlay"></div>
                    <div className="absolute inset-0 bg-gradient-to-t from-white via-white/10 to-transparent"></div>
                    
                    {/* Scanning Line Animation */}
                    <motion.div 
                      className="absolute top-0 inset-x-0 h-[1.5px] bg-blue-600/30 blur-[1px] z-10"
                      animate={{ top: ['0%', '100%', '0%'] }}
                      transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
                    />
                 </div>

                 {/* Medicine Learning Specific UI Overlay for the 3rd Project */}
                 {index === 2 && (
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.8 }}
                      whileInView={{ opacity: 1, scale: 1 }}
                      className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[85%] bg-white/95 backdrop-blur-xl shadow-2xl rounded-xl p-6 border border-blue-100 z-20 pointer-events-none"
                    >
                       <div className="flex justify-between items-start mb-4">
                          <div>
                             <div className="text-[10px] font-mono text-blue-600 font-bold uppercase tracking-widest mb-1 flex items-center gap-1">
                                <Terminal size={10} /> MEDICINE_PROFILE_V2
                             </div>
                             <h4 className="text-slate-900 font-black text-xl tracking-tight leading-none">Amoxicillin (Oral)</h4>
                          </div>
                          <span className="bg-blue-600 text-white text-[9px] px-2 py-0.5 rounded font-black uppercase tracking-wider">Antibiotic</span>
                       </div>
                       
                       <div className="grid grid-cols-2 gap-5 mb-4">
                          <div className="space-y-1.5">
                             <p className="text-slate-400 font-[800] text-[9px] uppercase tracking-widest">Type / Group</p>
                             <p className="text-slate-700 text-[11px] font-bold">Penicillin-type</p>
                          </div>
                          <div className="space-y-1.5">
                             <p className="text-slate-400 font-[800] text-[9px] uppercase tracking-widest">Common Uses</p>
                             <p className="text-slate-700 text-[11px] font-bold">Bacterial Infections</p>
                          </div>
                       </div>

                       <div className="space-y-4 pt-4 border-t border-slate-100">
                          <div className="space-y-1.5">
                             <div className="flex items-center justify-between">
                                <p className="text-slate-400 font-[800] text-[9px] uppercase tracking-widest">Potential Side Effects</p>
                                <span className="text-[8px] text-orange-600 font-bold uppercase">Critical_View</span>
                             </div>
                             <div className="flex flex-wrap gap-1.5">
                                {['Nausea', 'Vomiting', 'Diarrhea', 'Rash'].map(se => (
                                   <span key={se} className="px-2 py-0.5 bg-slate-100 text-slate-500 text-[9px] font-bold rounded">{se}</span>
                                ))}
                             </div>
                          </div>

                          <div className="grid grid-cols-2 gap-4">
                             <div className="bg-green-50 p-2 rounded border border-green-100">
                                <p className="text-green-700 font-black text-[9px] uppercase tracking-widest mb-1">PROS</p>
                                <p className="text-green-800 text-[10px] font-medium leading-tight">Fast absorption, broad-spectrum effectiveness.</p>
                             </div>
                             <div className="bg-red-50 p-2 rounded border border-red-100">
                                <p className="text-red-700 font-black text-[9px] uppercase tracking-widest mb-1">CONS</p>
                                <p className="text-red-800 text-[10px] font-medium leading-tight">High resistance risk if misused, allergens.</p>
                             </div>
                          </div>
                       </div>
                    </motion.div>
                 )}

                 <div className="absolute top-6 right-6 z-10 flex flex-col gap-2 items-end">
                    <div className="px-2.5 py-1 bg-white/95 backdrop-blur-md border border-slate-200 rounded-md text-[9px] font-mono text-green-600 flex items-center gap-2 shadow-sm font-bold">
                       <ShieldCheck size={10} /> ASSET_TRANSFER_READY
                    </div>
                    <div className="px-2.5 py-1 bg-white/95 backdrop-blur-md border border-slate-200 rounded-md text-[9px] font-mono text-blue-600 flex items-center gap-2 shadow-sm font-bold">
                       <Activity size={10} /> UNIT_TESTS_100%
                    </div>
                    <div className="px-2.5 py-1 bg-white/95 backdrop-blur-md border border-slate-200 rounded-md text-[9px] font-mono text-slate-500 flex items-center gap-2 shadow-sm font-bold">
                       <Lock size={10} /> IP_SECURED
                    </div>
                 </div>

                 <div className="absolute bottom-8 left-8 z-10">
                    <div className="text-[9px] font-mono text-slate-500 uppercase tracking-[0.4em] font-bold mb-2 drop-shadow-sm bg-white/40 px-2 py-0.5 rounded">Technical_Reference_Asset</div>
                    <div className="h-[2px] w-24 bg-blue-600/40"></div>
                 </div>
              </div>
            </motion.div>
          ))}
        </div>
      </Section>
    </div>
  );
};

export default PortfolioPage;