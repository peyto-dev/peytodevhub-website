import React from 'react';
import { Users, Target, Heart, CheckCircle, Zap, Shield } from 'lucide-react';
import Section from '../components/Section';
import Button from '../components/Button';
import { Link } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';

const AboutPage: React.FC = () => {
  const { t } = useLanguage();

  return (
    <div className="pt-24 bg-white min-h-screen">
      <Section>
        <div className="grid md:grid-cols-2 gap-20 items-start">
          {/* Left Column - Text */}
          <div>
            <h1 className="text-[44px] md:text-[56px] font-[800] text-slate-900 mb-12 uppercase tracking-tight">{t.about.title}</h1>
            
            <div className="mb-12">
              <h3 className="text-xl font-[800] text-slate-900 mb-4 flex items-center gap-3 uppercase tracking-tight">
                <Target className="text-blue-600" size={22} /> {t.about.mission.title}
              </h3>
              <p className="text-lg text-slate-500 leading-relaxed font-medium">
                {t.about.mission.desc}
              </p>
            </div>

            <div className="mb-12">
              <h3 className="text-xl font-[800] text-slate-900 mb-4 flex items-center gap-3 uppercase tracking-tight">
                <Users className="text-blue-600" size={22} /> {t.about.who.title}
              </h3>
              <p className="text-lg text-slate-500 leading-relaxed font-medium">
                {t.about.who.desc}
              </p>
            </div>

            <div className="mb-12">
              <h3 className="text-xl font-[800] text-slate-900 mb-6 uppercase tracking-tight">{t.about.beliefs.title}</h3>
              <div className="grid grid-cols-1 gap-4">
                {t.about.beliefs.list.map((belief, i) => (
                  <div key={i} className="flex items-center gap-4 text-slate-600 bg-slate-50 p-5 rounded border border-slate-100 shadow-sm font-bold text-[15px]">
                    <CheckCircle size={18} className="text-green-600 shrink-0" />
                    {belief}
                  </div>
                ))}
              </div>
            </div>
            
            <Link to="/contact">
               <Button className="h-14 px-10 font-bold uppercase tracking-widest rounded-full border-none">
                 {t.about.work_with_us}
               </Button>
            </Link>
          </div>

          {/* Right Column - Dashboard Card */}
          <div className="lg:sticky lg:top-32">
            <div className="bg-slate-50 border border-slate-100 p-12 rounded-lg shadow-xl">
              <div className="flex items-center gap-4 mb-8">
                 <div className="w-12 h-12 rounded bg-white border border-slate-200 flex items-center justify-center">
                    <Heart className="fill-blue-600 text-blue-600" size={24} />
                 </div>
                 <h3 className="text-2xl font-[800] text-slate-900 uppercase tracking-tight">{t.about.ngo_card.title}</h3>
              </div>
              <p className="text-[16px] text-slate-500 mb-10 leading-relaxed font-medium">
                {t.about.ngo_card.desc}
              </p>
              <div className="h-2 bg-slate-200 rounded-full overflow-hidden mb-4">
                <div className="h-full w-full bg-blue-600"></div>
              </div>
              <div className="flex justify-between items-center">
                 <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest font-bold">Progress_Indicator</span>
                 <span className="text-[11px] text-blue-600 font-[800] uppercase tracking-widest">{t.about.ngo_card.target}</span>
              </div>
              
              <div className="mt-12 pt-12 border-t border-slate-200">
                 <p className="text-slate-400 text-sm leading-relaxed italic font-medium">
                    "We believe professional software delivery requires more than technical skill. It requires clarity, accountability, and a responsible approach to how a company operates."
                 </p>
              </div>
            </div>
          </div>
        </div>
      </Section>

      {/* Why Choose Us Section */}
      <Section className="bg-slate-50 border-y border-slate-100">
        <div className="text-center mb-20">
          <h2 className="text-[32px] md:text-[40px] font-[800] text-slate-900 uppercase tracking-tight leading-tight">{t.about.why.title}</h2>
        </div>
        
        <div className="grid md:grid-cols-3 gap-10">
          {t.about.why.items.map((item, i) => {
            const icons = [Shield, Zap, CheckCircle];
            const Icon = icons[i] || CheckCircle;
            
            return (
              <div key={i} className="bg-white border border-slate-100 p-10 rounded-lg hover:border-blue-200 transition-all duration-300 shadow-sm group">
                <div className="w-14 h-14 rounded bg-slate-50 border border-slate-100 flex items-center justify-center mb-8 text-slate-400 group-hover:bg-blue-50 group-hover:text-blue-600 transition-colors">
                  <Icon size={28} />
                </div>
                <h3 className="text-xl font-[800] text-slate-900 mb-5 uppercase tracking-tight">{item.title}</h3>
                <p className="text-slate-500 text-[15px] leading-relaxed font-medium">
                  {item.desc}
                </p>
              </div>
            );
          })}
        </div>
      </Section>
    </div>
  );
};

export default AboutPage;