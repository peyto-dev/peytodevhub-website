import React from 'react';
import { Database, Cpu, ArrowRight, Terminal, CheckCircle } from 'lucide-react';
import Section from '../components/Section';
import Button from '../components/Button';
import { Link } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';

const ServicesPage: React.FC = () => {
  const { t } = useLanguage();

  return (
    <div className="pt-24 bg-white">
      <Section>
        <div className="mb-20">
          <span className="text-blue-600 font-mono text-[10px] tracking-[0.25em] font-[800] uppercase mb-4 block">{t.services.label}</span>
          <h1 className="text-[44px] md:text-[56px] font-[800] text-slate-900 mb-8 uppercase tracking-tight">{t.services.title}</h1>
          <p className="text-xl text-slate-500 max-w-3xl font-medium leading-relaxed">
            {t.services.desc}
          </p>
        </div>

        <div className="space-y-32">
          {/* Service 1: SaaS */}
          <div id="saas-engineering" className="grid md:grid-cols-2 gap-16 items-center">
            <div className="order-2 md:order-1">
              <div className="w-14 h-14 rounded bg-blue-50 border border-blue-100 flex items-center justify-center mb-8">
                <Database size={28} className="text-blue-600" />
              </div>
              <h2 className="text-3xl font-[800] text-slate-900 mb-6 tracking-tight uppercase">{t.services.s1.title}</h2>
              <p className="text-slate-500 text-lg mb-8 leading-relaxed font-medium">
                {t.services.s1.desc}
              </p>
              <ul className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-10">
                {t.services.s1.features.map((item, i) => (
                  <li key={i} className="flex items-center gap-3 text-slate-600 text-sm font-bold">
                    <CheckCircle size={18} className="text-blue-600 shrink-0" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div className="order-1 md:order-2 bg-slate-50 border border-slate-100 p-10 rounded shadow-lg">
               <div className="font-mono text-[11px] space-y-6 text-slate-400">
                  <div className="flex items-center gap-3 text-blue-600 font-bold">
                     <Terminal size={14} />
                     <span>SLA_UPTIME_VERIFIED</span>
                  </div>
                  <div className="space-y-2 p-5 bg-white border border-slate-100 rounded">
                     <div className="text-slate-900 font-bold">SERVICE_AVAILABILITY: 99.99%</div>
                     <div>HEALTH_CHECK: SUCCESS (Node v20.x)</div>
                     <div>OWNERSHIP_LOCK: RELEASED_TO_CLIENT</div>
                  </div>
               </div>
            </div>
          </div>

          {/* Service 2: Mobile */}
          <div id="mobile-development" className="grid md:grid-cols-2 gap-16 items-center">
            <div className="bg-slate-50 border border-slate-100 p-10 rounded shadow-lg h-96 flex items-center justify-center">
               <div className="relative w-40 h-72 bg-white border-[6px] border-slate-200 rounded-[2rem] shadow-2xl overflow-hidden">
                  <div className="absolute top-0 inset-x-0 h-6 bg-transparent flex justify-center items-end">
                     <div className="w-16 h-3 bg-slate-200 rounded-b-xl"></div>
                  </div>
                  <div className="p-4 pt-10 space-y-4">
                     <div className="w-full h-8 bg-blue-50 rounded-lg"></div>
                     <div className="grid grid-cols-2 gap-2">
                        <div className="h-16 bg-slate-50 rounded-lg"></div>
                        <div className="h-16 bg-slate-50 rounded-lg"></div>
                     </div>
                  </div>
               </div>
            </div>
            <div>
              <div className="w-14 h-14 rounded bg-blue-50 border border-blue-100 flex items-center justify-center mb-8">
                <Cpu size={28} className="text-blue-600" />
              </div>
              <h2 className="text-3xl font-[800] text-slate-900 mb-6 tracking-tight uppercase">{t.services.s2.title}</h2>
              <p className="text-slate-500 text-lg mb-8 leading-relaxed font-medium">
                {t.services.s2.desc}
              </p>
              <ul className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-10">
                {t.services.s2.features.map((item, i) => (
                  <li key={i} className="flex items-center gap-3 text-slate-600 text-sm font-bold">
                    <CheckCircle size={18} className="text-blue-600 shrink-0" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        <div className="mt-32 text-center">
          <Link to="/contact">
            <Button variant="primary" className="h-14 px-12 text-base rounded-full border-none">
              {t.services.cta} <ArrowRight size={20} />
            </Button>
          </Link>
        </div>
      </Section>
    </div>
  );
};

export default ServicesPage;