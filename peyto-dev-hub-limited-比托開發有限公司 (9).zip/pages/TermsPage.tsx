import React from 'react';
import Section from '../components/Section';
import { useLanguage } from '../contexts/LanguageContext';
import { FileText, ArrowLeft } from 'lucide-react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

const TermsPage: React.FC = () => {
  const { t, language } = useLanguage();

  return (
    <div className="pt-24 bg-white min-h-screen">
      <Section>
        <div className="max-w-4xl mx-auto">
          <Link to="/" className="inline-flex items-center gap-2 text-[#64748B] hover:text-peyto-accent mb-10 transition-colors text-[11px] font-[800] uppercase tracking-widest group">
            <ArrowLeft size={14} className="group-hover:-translate-x-1 transition-transform" />
            {language === 'en' ? 'Back to Home' : '返回首頁'}
          </Link>
          
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="mb-12 border-b border-[#E2E8F0] pb-12"
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded bg-slate-50 border border-slate-100 flex items-center justify-center text-peyto-accent">
                 <FileText size={20} />
              </div>
              <span className="text-[#64748B] font-mono text-[10px] tracking-widest uppercase font-bold">Standard_Ops_Legal</span>
            </div>
            <h1 className="text-[44px] md:text-[52px] font-[800] text-[#0F172A] mb-4 uppercase tracking-tight">{t.terms_page.title}</h1>
            <p className="text-[#64748B] font-mono text-[11px] uppercase tracking-widest font-bold">{t.terms_page.last_updated}</p>
          </motion.div>

          <div className="space-y-12">
            <div className="max-w-none">
              <motion.p 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.2 }}
                className="text-lg text-[#334155] font-medium leading-relaxed mb-12"
              >
                {t.terms_page.intro}
              </motion.p>

              <div className="space-y-8">
                {t.terms_page.sections.map((section, index) => (
                  <motion.div 
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, margin: "-50px" }}
                    transition={{ delay: index * 0.1 }}
                    className="bg-white border border-[#E2E8F0] rounded-lg p-10 hover:border-peyto-accent/20 transition-colors shadow-sm"
                  >
                    <h3 className="text-[18px] font-[800] text-[#0F172A] mb-4 uppercase tracking-tight">{section.heading}</h3>
                    <p className="text-[#475569] text-[15px] leading-relaxed font-medium">
                      {section.content}
                    </p>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </Section>
    </div>
  );
};

export default TermsPage;